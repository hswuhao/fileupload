
    var MyComponent = Vue.extend(
    {
        template: '<h1>Test</h1>'
    });

    var MyComponent2 = Vue.extend(
    {
        template: '<ul><li>Home</li><li>About</li><li>Contact</li></ul>'
    });

    Vue.component('my-component', MyComponent)

    Vue.component('my-component2', MyComponent2)


    new Vue(
    {
        el: '#example'
    });    